package com.example.camscannerapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import static com.example.camscannerapplication.R.id.imgIcon;

public class DocumentationAdapter extends RecyclerView.Adapter<DocumentationAdapter.DocumentaionViewHolder>{
    private String[] data;
    public DocumentationAdapter(String[] data){
        this.data=data;
    }
    @NonNull
    @Override
    public DocumentaionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.list_item_layout,parent,false);
        return new DocumentaionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DocumentaionViewHolder holder, int position) {
         String title = data[position];
         holder.txtTitle.setText(title);
    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class DocumentaionViewHolder extends RecyclerView.ViewHolder{
        ImageView imgIcon;
        TextView txtTitle;
       public DocumentaionViewHolder(@NonNull View itemView) {
           super(itemView);
           imgIcon =(ImageView) itemView.findViewById(R.id.imgIcon);
           txtTitle =(TextView)  itemView.findViewById(R.id.txtTitle);
       }
   }
}
